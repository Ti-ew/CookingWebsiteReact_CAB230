// the footer
export default function Footer() {
  return (
    <footer>
      <span>
        Minty Yard
        <br />
        Copyright &copy; 2023{" "}
      </span>
    </footer>
  );
}
