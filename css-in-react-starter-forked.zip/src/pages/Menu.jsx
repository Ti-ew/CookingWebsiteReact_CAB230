import React from "react";

export default function Menu() {
  return <h2>Menu</h2>;
}
