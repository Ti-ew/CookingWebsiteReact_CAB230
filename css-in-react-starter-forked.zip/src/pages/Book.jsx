import React from "react";

export default function Book() {
  return <h2>Book</h2>;
}
